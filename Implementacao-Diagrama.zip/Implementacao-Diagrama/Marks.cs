// Classe Marks - implementado de acordo com o primeiro diagrama de classe
public class Marks
{
    public int ID { get; set; }
    public string Date { get; set; }
    public double Mark { get; set; }

    public int GetStudent()
    {
        // Falta implementar essa logica aqui
        return 0;
    }

    public int GetSubject()
    {
        // Falta implementar essa logica aqui
        return 0;
    }
}